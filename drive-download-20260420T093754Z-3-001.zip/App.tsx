// ─────────────────────────────────────────────────────────
// App.tsx — Root entry point
// Registers TrackPlayer background service BEFORE rendering.
// ─────────────────────────────────────────────────────────

import 'react-native-get-random-values'; // must be first
import React, { useEffect, useState } from 'react';
import { View, StyleSheet, LogBox } from 'react-native';
import { NavigationContainer }      from '@react-navigation/native';
import { SafeAreaProvider }         from 'react-native-safe-area-context';
import { Provider as ReduxProvider } from 'react-redux';
import { PersistGate }              from 'redux-persist/integration/react';
import TrackPlayer                  from 'react-native-track-player';
import { StatusBar }                from 'expo-status-bar';
import * as SplashScreen            from 'expo-splash-screen';
import * as Font                    from 'expo-font';

import { store, persistor }         from './src/store';
import { AudioService, playbackService } from './src/services/AudioService';
import RootNavigator                from './src/navigation/TabNavigator';
import { Colors }                   from './src/constants/theme';

// Keep splash visible while loading fonts
SplashScreen.preventAutoHideAsync().catch(() => {});

// Suppress minor React Native warnings
LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'Sending `onAnimatedValueUpdate`',
]);

// ── Register background service (must be top-level, not inside render) ──
TrackPlayer.registerPlaybackService(() => playbackService);

export default function App() {
  const [appReady, setAppReady] = useState(false);

  useEffect(() => {
    async function prepare() {
      try {
        // Load custom fonts
        await Font.loadAsync({
          'Outfit-Regular':  require('./src/assets/fonts/Outfit-Regular.ttf'),
          'Outfit-Medium':   require('./src/assets/fonts/Outfit-Medium.ttf'),
          'Outfit-SemiBold': require('./src/assets/fonts/Outfit-SemiBold.ttf'),
          'Outfit-Bold':     require('./src/assets/fonts/Outfit-Bold.ttf'),
          'Outfit-Black':    require('./src/assets/fonts/Outfit-Black.ttf'),
        });
      } catch (e) {
        // Fonts optional — system font fallback works fine
        console.warn('Font load failed, using system fallback:', e);
      }

      // Setup audio player (background service + lock-screen controls)
      await AudioService.setup();

      setAppReady(true);
      await SplashScreen.hideAsync();
    }

    prepare();
  }, []);

  if (!appReady) {
    return (
      <View style={styles.splash}>
        <StatusBar style="light" />
      </View>
    );
  }

  return (
    <ReduxProvider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <SafeAreaProvider>
          <NavigationContainer
            theme={{
              dark:   true,
              colors: {
                primary:    Colors.accent,
                background: Colors.bg,
                card:       Colors.surface,
                text:       Colors.text,
                border:     Colors.border,
                notification: Colors.accent,
              },
            }}
          >
            <StatusBar style="light" />
            <RootNavigator />
          </NavigationContainer>
        </SafeAreaProvider>
      </PersistGate>
    </ReduxProvider>
  );
}

const styles = StyleSheet.create({
  splash: {
    flex:            1,
    backgroundColor: Colors.bg,
    alignItems:      'center',
    justifyContent:  'center',
  },
});
