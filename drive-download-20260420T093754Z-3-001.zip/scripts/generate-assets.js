#!/usr/bin/env node
// ─────────────────────────────────────────────────────────
// scripts/generate-assets.js
// Creates minimal PNG placeholder assets so the project
// builds without needing real design files.
// Run once: node scripts/generate-assets.js
// ─────────────────────────────────────────────────────────

const { createCanvas } = require('canvas');  // npm i canvas
const fs = require('fs');
const path = require('path');

const ASSETS_DIR = path.join(__dirname, '../src/assets');
if (!fs.existsSync(ASSETS_DIR)) fs.mkdirSync(ASSETS_DIR, { recursive: true });

function makeSquare(filename, size, bg, text) {
  const canvas = createCanvas(size, size);
  const ctx    = canvas.getContext('2d');

  // Background
  const grad = ctx.createLinearGradient(0, 0, size, size);
  grad.addColorStop(0, '#FF4500');
  grad.addColorStop(1, '#FFB400');
  ctx.fillStyle = bg || grad;
  ctx.fillRect(0, 0, size, size);

  // Text
  if (text) {
    ctx.fillStyle    = 'rgba(255,255,255,0.9)';
    ctx.font         = `bold ${size * 0.15}px sans-serif`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, size / 2, size / 2);
  }

  fs.writeFileSync(path.join(ASSETS_DIR, filename), canvas.toBuffer('image/png'));
  console.log(`✅ Created ${filename}`);
}

makeSquare('icon.png',          1024, null,      '🎵');
makeSquare('adaptive-icon.png', 1024, '#07070F', '🎵');
makeSquare('splash.png',        2048, '#07070F', 'Tamil Tunes');
makeSquare('favicon.png',        196, null,      '🎵');
makeSquare('placeholder.png',    500, '#1F1F38', '♪');

console.log('\n✅ All assets generated in src/assets/');
console.log('🎨 Replace with your real designs before publishing.\n');
