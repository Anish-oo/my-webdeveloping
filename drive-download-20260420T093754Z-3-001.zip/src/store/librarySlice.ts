// ─────────────────────────────────────────────────────────
// store/librarySlice.ts — Liked songs, playlists, history
// ─────────────────────────────────────────────────────────

import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Song, Playlist, LibraryState } from '../types';

const RECENTLY_PLAYED_LIMIT = 30;

const initialState: LibraryState = {
  likedSongs:      [],
  playlists:       [],
  recentlyPlayed:  [],
  downloadedSongs: [],
};

const librarySlice = createSlice({
  name: 'library',
  initialState,
  reducers: {
    toggleLike(state, action: PayloadAction<Song>) {
      const song = action.payload;
      const idx  = state.likedSongs.findIndex(s => s.id === song.id);
      if (idx >= 0) {
        state.likedSongs.splice(idx, 1);
      } else {
        state.likedSongs.unshift({ ...song, isLiked: true });
      }
    },

    addToRecentlyPlayed(state, action: PayloadAction<Song>) {
      const song = action.payload;
      state.recentlyPlayed = [
        song,
        ...state.recentlyPlayed.filter(s => s.id !== song.id),
      ].slice(0, RECENTLY_PLAYED_LIMIT);
    },

    createPlaylist(state, action: PayloadAction<{ name: string; description: string }>) {
      const pl: Playlist = {
        id:            `user_${Date.now()}`,
        name:          action.payload.name,
        description:   action.payload.description,
        songs:         [],
        isUserCreated: true,
        createdAt:     Date.now(),
      };
      state.playlists.push(pl);
    },

    deletePlaylist(state, action: PayloadAction<string>) {
      state.playlists = state.playlists.filter(p => p.id !== action.payload);
    },

    addSongToPlaylist(state, action: PayloadAction<{ playlistId: string; song: Song }>) {
      const pl = state.playlists.find(p => p.id === action.payload.playlistId);
      if (pl && !pl.songs.find(s => s.id === action.payload.song.id)) {
        pl.songs.push(action.payload.song);
      }
    },

    removeSongFromPlaylist(state, action: PayloadAction<{ playlistId: string; songId: string }>) {
      const pl = state.playlists.find(p => p.id === action.payload.playlistId);
      if (pl) {
        pl.songs = pl.songs.filter(s => s.id !== action.payload.songId);
      }
    },
  },
});

export const {
  toggleLike,
  addToRecentlyPlayed,
  createPlaylist,
  deletePlaylist,
  addSongToPlaylist,
  removeSongFromPlaylist,
} = librarySlice.actions;

export default librarySlice.reducer;
