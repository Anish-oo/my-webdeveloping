// ─────────────────────────────────────────────────────────
// store/playerSlice.ts — Redux Toolkit slice for audio player
// ─────────────────────────────────────────────────────────

import { createSlice, PayloadAction, createAsyncThunk } from '@reduxjs/toolkit';
import TrackPlayer, {
  Track,
  RepeatMode,
  State as TPState,
} from 'react-native-track-player';
import { Song, PlayerState } from '../types';

// ─── Thunks (async actions) ───────────────────────────────

export const playSong = createAsyncThunk(
  'player/playSong',
  async ({ song, queue }: { song: Song; queue: Song[] }) => {
    await TrackPlayer.reset();

    const tracks: Track[] = queue.map(s => ({
      id:       s.id,
      url:      s.audioUrl,
      title:    s.title,
      artist:   s.artist,
      album:    s.album,
      artwork:  s.thumbnail,
      duration: s.duration,
    }));

    await TrackPlayer.add(tracks);

    const index = queue.findIndex(s => s.id === song.id);
    if (index > 0) await TrackPlayer.skip(index);

    await TrackPlayer.play();
    return { song, queue, index: Math.max(0, index) };
  }
);

export const skipToNext = createAsyncThunk('player/next', async () => {
  await TrackPlayer.skipToNext();
});

export const skipToPrevious = createAsyncThunk('player/prev', async () => {
  await TrackPlayer.skipToPrevious();
});

export const togglePlayPause = createAsyncThunk(
  'player/togglePlayPause',
  async (_, { getState }) => {
    const state = (getState() as any).player as PlayerState;
    if (state.isPlaying) {
      await TrackPlayer.pause();
    } else {
      await TrackPlayer.play();
    }
    return !state.isPlaying;
  }
);

export const seekTo = createAsyncThunk(
  'player/seekTo',
  async (position: number) => {
    await TrackPlayer.seekTo(position);
    return position;
  }
);

export const setRepeat = createAsyncThunk(
  'player/setRepeat',
  async (mode: 'off' | 'all' | 'one') => {
    const rm =
      mode === 'off' ? RepeatMode.Off :
      mode === 'one' ? RepeatMode.Track :
                       RepeatMode.Queue;
    await TrackPlayer.setRepeatMode(rm);
    return mode;
  }
);

// ─── Slice ────────────────────────────────────────────────

const initialState: PlayerState = {
  currentSong:  null,
  queue:        [],
  queueIndex:   0,
  isPlaying:    false,
  isBuffering:  false,
  progress:     0,
  duration:     0,
  position:     0,
  shuffle:      false,
  repeatMode:   'off',
  volume:       1,
};

const playerSlice = createSlice({
  name: 'player',
  initialState,
  reducers: {
    // Called by useTrackPlayerEvents listener
    setPlaybackState(state, action: PayloadAction<{ state: TPState; position: number; duration: number }>) {
      const { state: ps, position, duration } = action.payload;
      state.isPlaying   = ps === TPState.Playing;
      state.isBuffering = ps === TPState.Buffering || ps === TPState.Loading;
      state.position    = position;
      state.duration    = duration;
      state.progress    = duration > 0 ? position / duration : 0;
    },
    setProgress(state, action: PayloadAction<{ position: number; duration: number }>) {
      state.position = action.payload.position;
      state.duration = action.payload.duration;
      state.progress = action.payload.duration > 0
        ? action.payload.position / action.payload.duration
        : 0;
    },
    setCurrentSong(state, action: PayloadAction<Song>) {
      state.currentSong = action.payload;
    },
    toggleShuffle(state) {
      state.shuffle = !state.shuffle;
    },
    setVolume(state, action: PayloadAction<number>) {
      state.volume = action.payload;
    },
    addToQueue(state, action: PayloadAction<Song>) {
      state.queue.push(action.payload);
    },
    clearQueue(state) {
      state.queue = [];
    },
  },
  extraReducers: builder => {
    builder
      .addCase(playSong.fulfilled, (state, action) => {
        state.currentSong = action.payload.song;
        state.queue       = action.payload.queue;
        state.queueIndex  = action.payload.index;
        state.isPlaying   = true;
        state.progress    = 0;
        state.position    = 0;
      })
      .addCase(togglePlayPause.fulfilled, (state, action) => {
        state.isPlaying = action.payload;
      })
      .addCase(seekTo.fulfilled, (state, action) => {
        state.position = action.payload;
        state.progress = state.duration > 0 ? action.payload / state.duration : 0;
      })
      .addCase(setRepeat.fulfilled, (state, action) => {
        state.repeatMode = action.payload;
      });
  },
});

export const {
  setPlaybackState,
  setProgress,
  setCurrentSong,
  toggleShuffle,
  setVolume,
  addToQueue,
  clearQueue,
} = playerSlice.actions;

export default playerSlice.reducer;
