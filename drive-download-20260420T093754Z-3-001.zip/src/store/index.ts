// ─────────────────────────────────────────────────────────
// store/index.ts — Root Redux store + persistence
// ─────────────────────────────────────────────────────────

import { configureStore, combineReducers } from '@reduxjs/toolkit';
import {
  persistStore,
  persistReducer,
  FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER,
} from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';

import playerReducer  from './playerSlice';
import libraryReducer from './librarySlice';

const rootReducer = combineReducers({
  player:  playerReducer,
  library: libraryReducer,
});

const persistConfig = {
  key:       'root',
  storage:   AsyncStorage,
  whitelist: ['library'], // only persist library; player state resets on app launch
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
  reducer: persistedReducer,
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
});

export const persistor = persistStore(store);

export type RootState    = ReturnType<typeof rootReducer>;
export type AppDispatch  = typeof store.dispatch;
