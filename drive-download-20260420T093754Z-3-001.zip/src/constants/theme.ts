// ─────────────────────────────────────────────────────────
// Theme & Design Tokens — Tamil Tunes
// ─────────────────────────────────────────────────────────

export const Colors = {
  // Backgrounds
  bg:        '#07070F',
  surface:   '#0F0F1E',
  surface2:  '#181830',
  surface3:  '#21213A',
  overlay:   'rgba(7,7,15,0.86)',

  // Accent
  accent:    '#FF4500',      // Tamil red-orange
  accentAlt: '#FFB400',      // golden
  accentDim: 'rgba(255,69,0,0.18)',

  // Text
  text:      '#F2F2FA',
  text2:     '#8888AA',
  text3:     '#44445A',
  textInv:   '#07070F',

  // Status
  success:   '#30D158',
  warning:   '#FFB400',
  error:     '#FF453A',

  // Misc
  border:    'rgba(255,255,255,0.08)',
  shadow:    'rgba(0,0,0,0.7)',
};

export const GRADIENTS: [string, string][] = [
  ['#FF416C', '#FF4B2B'],
  ['#4776E6', '#8E54E9'],
  ['#11998e', '#38ef7d'],
  ['#F7971E', '#FFD200'],
  ['#c94b4b', '#4b134f'],
  ['#8360c3', '#2ebf91'],
  ['#FC4A1A', '#F7B733'],
  ['#f953c6', '#b91d73'],
  ['#0F2027', '#4286f4'],
  ['#ee0979', '#ff6a00'],
  ['#7F00FF', '#E100FF'],
  ['#30cfd0', '#330867'],
  ['#FF512F', '#DD2476'],
  ['#1D976C', '#93F9B9'],
  ['#373B44', '#4286f4'],
  ['#16213e', '#e94560'],
];

export const Typography = {
  // Font families (loaded via expo-font or system)
  heading:  'Outfit-Black',
  bold:     'Outfit-Bold',
  semibold: 'Outfit-SemiBold',
  medium:   'Outfit-Medium',
  regular:  'Outfit-Regular',

  // Sizes
  xs:   10,
  sm:   12,
  md:   14,
  base: 16,
  lg:   18,
  xl:   22,
  '2xl':26,
  '3xl':32,
  '4xl':38,
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  '2xl': 32,
  '3xl': 48,
};

export const Radius = {
  sm:   8,
  md:   14,
  lg:   18,
  xl:   24,
  full: 9999,
};

export const Shadow = {
  card: {
    shadowColor: Colors.shadow,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.5,
    shadowRadius: 24,
    elevation: 12,
  },
  player: {
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.5,
    shadowRadius: 40,
    elevation: 20,
  },
};

// Curated playlists shown on Home
export const CURATED_PLAYLISTS = [
  { id:'pl_iraiyaraaja', name:'Ilaiyaraaja Hits',      query:'ilaiyaraaja tamil',        gradient:GRADIENTS[3]  as [string,string] },
  { id:'pl_arrahman',    name:'A.R. Rahman Gold',       query:'ar rahman tamil',           gradient:GRADIENTS[1]  as [string,string] },
  { id:'pl_anirudh',     name:'Anirudh Anthems',        query:'anirudh ravichander hits',  gradient:GRADIENTS[10] as [string,string] },
  { id:'pl_yuvan',       name:'Yuvan Beats',            query:'yuvan shankar raja tamil',  gradient:GRADIENTS[7]  as [string,string] },
  { id:'pl_80s',         name:'80s Classics',           query:'ilaiyaraaja 1980s melody',  gradient:GRADIENTS[4]  as [string,string] },
  { id:'pl_90s',         name:'90s Golden Era',         query:'ar rahman 1990s tamil',     gradient:GRADIENTS[0]  as [string,string] },
  { id:'pl_2000s',       name:'2000s Blockbusters',     query:'harris jayaraj 2000s hits', gradient:GRADIENTS[5]  as [string,string] },
  { id:'pl_2010s',       name:'2010s Fresh Hits',       query:'anirudh 2010s tamil hits',  gradient:GRADIENTS[2]  as [string,string] },
  { id:'pl_love',        name:'❤️ Love Melodies',       query:'tamil love melody songs',   gradient:GRADIENTS[12] as [string,string] },
  { id:'pl_kuthu',       name:'🔥 Kuthu Vibes',         query:'tamil kuthu dance songs',   gradient:GRADIENTS[9]  as [string,string] },
];

export const TOP_ARTISTS = [
  { name:'Ilaiyaraaja',         query:'ilaiyaraaja',          color:'#F7971E' },
  { name:'A.R. Rahman',         query:'ar rahman',            color:'#4776E6' },
  { name:'Harris Jayaraj',      query:'harris jayaraj',       color:'#11998e' },
  { name:'Yuvan Shankar Raja',  query:'yuvan shankar raja',   color:'#ee0979' },
  { name:'Anirudh Ravichander', query:'anirudh ravichander',  color:'#8360c3' },
  { name:'GV Prakash Kumar',    query:'gv prakash kumar',     color:'#FC4A1A' },
  { name:'D. Imman',            query:'d imman',              color:'#30cfd0' },
  { name:'Govind Vasantha',     query:'govind vasantha',      color:'#1D976C' },
  { name:'Vidyasagar',          query:'vidyasagar tamil',     color:'#FF512F' },
];
