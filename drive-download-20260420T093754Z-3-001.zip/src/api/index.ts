// ─────────────────────────────────────────────────────────
// api/index.ts — Central API export
//
// ✅ To swap to a different music source in the future:
//    1. Create NewProvider.ts implementing IMusicProvider
//    2. Replace the line below:
//       export const MusicAPI = new NewProvider();
// ─────────────────────────────────────────────────────────

import { JioSaavnProvider } from './JioSaavnProvider';

export const MusicAPI = new JioSaavnProvider();

// Re-export the interface so consumers can type-hint without
// depending on the concrete implementation.
export type { IMusicProvider } from '../types';
