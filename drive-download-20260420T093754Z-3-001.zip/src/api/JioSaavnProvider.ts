// ─────────────────────────────────────────────────────────
// JioSaavnProvider.ts
// Real music data from the unofficial JioSaavn REST API
// Docs: https://saavn.dev  (open-source, no key needed)
//
// HOW TO SWAP THIS SOURCE:
//   1. Create a new file, e.g. YTMusicProvider.ts
//   2. Implement the IMusicProvider interface
//   3. In api/index.ts change:
//        export const MusicAPI = new JioSaavnProvider();
//      → export const MusicAPI = new YTMusicProvider();
// ─────────────────────────────────────────────────────────

import { IMusicProvider, Song, Artist } from '../types';

const BASE_URL = 'https://saavn.dev/api';

// Saavn API quality: 12kbps, 48kbps, 96kbps, 160kbps, 320kbps
const AUDIO_QUALITY = '160kbps';
const IMG_QUALITY   = '500x500';

// ─── Raw API → App Model mapper ──────────────────────────
function mapSong(raw: any): Song | null {
  try {
    // Find best audio URL
    const downloadUrls: { quality: string; url: string }[] =
      raw.downloadUrl ?? raw.download_url ?? [];

    const audioEntry =
      downloadUrls.find((d: any) => d.quality === AUDIO_QUALITY) ??
      downloadUrls.find((d: any) => d.quality === '96kbps') ??
      downloadUrls[downloadUrls.length - 1];

    if (!audioEntry?.url) return null;

    // Images
    const images: { quality: string; url: string }[] =
      raw.image ?? [];
    const thumbHigh =
      images.find((i: any) => i.quality === IMG_QUALITY)?.url ??
      images[images.length - 1]?.url ?? '';
    const thumbLow  =
      images.find((i: any) => i.quality === '50x50')?.url ??
      thumbHigh;

    // Artists
    const primaryArtists: any[] =
      raw.artists?.primary ?? raw.primaryArtists ?? [];
    const artistName = primaryArtists.map((a: any) => a.name).join(', ')
      || raw.primaryArtists
      || 'Unknown Artist';

    // Year extraction
    let year = parseInt(raw.year ?? '1980', 10);
    if (isNaN(year) || year < 1980 || year > 2026) return null; // strict year gate

    return {
      id:           String(raw.id),
      title:        decodeHTML(raw.name ?? raw.title ?? ''),
      artist:       decodeHTML(artistName),
      album:        decodeHTML(raw.album?.name ?? raw.album ?? ''),
      year,
      duration:     parseInt(raw.duration ?? '0', 10),
      audioUrl:     audioEntry.url,
      thumbnail:    thumbHigh,
      thumbnailLow: thumbLow,
      language:     (raw.language ?? '').toLowerCase(),
    };
  } catch {
    return null;
  }
}

function mapArtist(raw: any): Artist {
  const images: { quality: string; url: string }[] = raw.image ?? [];
  return {
    id:       String(raw.id ?? ''),
    name:     raw.name ?? '',
    imageUrl: images[images.length - 1]?.url ?? '',
    bio:      raw.bio?.[0]?.text ?? '',
  };
}

function decodeHTML(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
}

async function fetchJSON(url: string): Promise<any> {
  const resp = await fetch(url, {
    headers: { Accept: 'application/json' },
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status} → ${url}`);
  return resp.json();
}

// ─── Provider Class ───────────────────────────────────────
export class JioSaavnProvider implements IMusicProvider {

  // Generic search helper
  private async _search(query: string, limit = 20, page = 1): Promise<Song[]> {
    const url = `${BASE_URL}/search/songs?query=${encodeURIComponent(query)}&limit=${limit}&page=${page}`;
    const data = await fetchJSON(url);
    const results: any[] = data?.data?.results ?? [];
    return results
      .map(mapSong)
      .filter((s): s is Song => s !== null && s.language === 'tamil');
  }

  async getSongs(page = 1, limit = 30): Promise<Song[]> {
    // Cycle through popular Tamil search terms to surface variety
    const terms = [
      'ilaiyaraaja tamil hits',
      'ar rahman tamil songs',
      'anirudh tamil hits',
      'yuvan shankar raja tamil',
      'harris jayaraj tamil melody',
    ];
    const term = terms[(page - 1) % terms.length];
    return this._search(term, limit, 1);
  }

  async searchSongs(query: string, limit = 30): Promise<Song[]> {
    return this._search(`${query} tamil`, limit);
  }

  async getSongsByArtist(artist: string, limit = 30): Promise<Song[]> {
    return this._search(`${artist} tamil songs`, limit);
  }

  async getSongsByYear(year: number, limit = 20): Promise<Song[]> {
    // JioSaavn doesn't have a direct year filter; we filter post-fetch
    const raw = await this._search(`tamil ${year} hits`, limit * 2);
    return raw.filter(s => s.year === year).slice(0, limit);
  }

  async getSongsByDecade(from: number, to: number, limit = 30): Promise<Song[]> {
    const mid = Math.floor((from + to) / 2);
    const raw = await this._search(`tamil ${from}s ${mid}s songs`, limit * 2);
    return raw.filter(s => s.year >= from && s.year <= to).slice(0, limit);
  }

  async getSongById(id: string): Promise<Song | null> {
    const url = `${BASE_URL}/songs/${id}`;
    try {
      const data = await fetchJSON(url);
      const raw = data?.data?.[0] ?? null;
      return raw ? mapSong(raw) : null;
    } catch {
      return null;
    }
  }

  async getFeaturedSongs(limit = 20): Promise<Song[]> {
    const queries = [
      'anirudh vaathi coming',
      'ar rahman ponniyin selvan',
      'ilaiyaraaja melody hits',
    ];
    const results = await Promise.allSettled(
      queries.map(q => this._search(q, Math.ceil(limit / queries.length)))
    );
    const all: Song[] = [];
    for (const r of results) {
      if (r.status === 'fulfilled') all.push(...r.value);
    }
    // Deduplicate
    const seen = new Set<string>();
    return all.filter(s => {
      if (seen.has(s.id)) return false;
      seen.add(s.id); return true;
    }).slice(0, limit);
  }

  async searchArtists(query: string): Promise<Artist[]> {
    const url = `${BASE_URL}/search/artists?query=${encodeURIComponent(query + ' tamil')}&limit=10`;
    const data = await fetchJSON(url);
    const results: any[] = data?.data?.results ?? [];
    return results.map(mapArtist);
  }
}
