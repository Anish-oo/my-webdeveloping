// ─────────────────────────────────────────────────────────
// services/AudioService.ts
// Registers with react-native-track-player.
// This file runs in a SEPARATE background thread on Android
// and keeps music playing when the screen is off / app minimised.
// ─────────────────────────────────────────────────────────

import TrackPlayer, {
  AppKilledPlaybackBehavior,
  Capability,
  Event,
} from 'react-native-track-player';

/**
 * Called once on app boot from App.tsx:
 *   await AudioService.setup();
 */
export class AudioService {

  static async setup(): Promise<void> {
    try {
      await TrackPlayer.setupPlayer({
        // Android: keep alive even when app is killed
        android: {
          appKilledPlaybackBehavior:
            AppKilledPlaybackBehavior.StopPlaybackAndRemoveNotification,
        },
        // Buffer ahead 60 s, min 15 s before starting playback
        minBuffer:    15,
        maxBuffer:    60,
        playBuffer:   3,
        backBuffer:   30,
      });

      await TrackPlayer.updateOptions({
        // Lock-screen / notification controls
        capabilities: [
          Capability.Play,
          Capability.Pause,
          Capability.SkipToNext,
          Capability.SkipToPrevious,
          Capability.SeekTo,
        ],
        compactCapabilities: [
          Capability.Play,
          Capability.Pause,
          Capability.SkipToNext,
        ],
        notificationCapabilities: [
          Capability.Play,
          Capability.Pause,
          Capability.SkipToNext,
          Capability.SkipToPrevious,
        ],
        // Android notification style
        android: {
          appKilledPlaybackBehavior:
            AppKilledPlaybackBehavior.StopPlaybackAndRemoveNotification,
        },
        progressUpdateEventInterval: 1, // seconds
      });
    } catch (err) {
      // Player already set up (hot reload) — safe to ignore
      console.log('TrackPlayer already initialised', err);
    }
  }
}

/**
 * playbackService — registered as the background task handler.
 * Must be exported as DEFAULT from this file (or a dedicated file).
 * Register in App.tsx:
 *   TrackPlayer.registerPlaybackService(() => playbackService);
 */
export async function playbackService() {
  // remote-play / pause / skip events fired by lock-screen controls,
  // headphone buttons, Android Auto, etc.
  TrackPlayer.addEventListener(Event.RemotePlay,     () => TrackPlayer.play());
  TrackPlayer.addEventListener(Event.RemotePause,    () => TrackPlayer.pause());
  TrackPlayer.addEventListener(Event.RemoteNext,     () => TrackPlayer.skipToNext());
  TrackPlayer.addEventListener(Event.RemotePrevious, () => TrackPlayer.skipToPrevious());
  TrackPlayer.addEventListener(Event.RemoteSeek,     e  => TrackPlayer.seekTo(e.position));
  TrackPlayer.addEventListener(Event.RemoteStop,     () => TrackPlayer.reset());

  // Android: duck audio when a phone call comes in
  TrackPlayer.addEventListener(Event.RemoteDuck, async ({ paused, permanent }) => {
    if (permanent) {
      await TrackPlayer.pause();
    } else if (paused) {
      await TrackPlayer.setVolume(0.3);
    } else {
      await TrackPlayer.setVolume(1.0);
    }
  });
}
