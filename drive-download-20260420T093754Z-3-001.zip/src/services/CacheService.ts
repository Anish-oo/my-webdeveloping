// ─────────────────────────────────────────────────────────
// services/CacheService.ts
// Stores recent API responses in AsyncStorage so the app
// feels snappy on second visit and works partially offline.
// ─────────────────────────────────────────────────────────

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Song } from '../types';

const TTL_MS   = 1000 * 60 * 60 * 6; // 6 hours
const MAX_KEYS = 30;

interface CacheEntry<T> {
  data:       T;
  cachedAt:   number;
}

export class CacheService {

  private static key(id: string) { return `cache:${id}`; }

  static async get<T>(id: string): Promise<T | null> {
    try {
      const raw = await AsyncStorage.getItem(CacheService.key(id));
      if (!raw) return null;
      const entry: CacheEntry<T> = JSON.parse(raw);
      if (Date.now() - entry.cachedAt > TTL_MS) {
        await AsyncStorage.removeItem(CacheService.key(id));
        return null;
      }
      return entry.data;
    } catch {
      return null;
    }
  }

  static async set<T>(id: string, data: T): Promise<void> {
    try {
      const entry: CacheEntry<T> = { data, cachedAt: Date.now() };
      await AsyncStorage.setItem(CacheService.key(id), JSON.stringify(entry));
      await CacheService.evictOld();
    } catch {
      // Storage full — silently ignore
    }
  }

  static async getSongs(key: string): Promise<Song[] | null> {
    return CacheService.get<Song[]>(key);
  }

  static async setSongs(key: string, songs: Song[]): Promise<void> {
    return CacheService.set<Song[]>(key, songs);
  }

  /** Remove oldest entries when store grows too large */
  private static async evictOld(): Promise<void> {
    try {
      const allKeys = (await AsyncStorage.getAllKeys()).filter(k => k.startsWith('cache:'));
      if (allKeys.length <= MAX_KEYS) return;
      // Delete the oldest half
      const toDelete = allKeys.slice(0, allKeys.length - MAX_KEYS);
      await AsyncStorage.multiRemove(toDelete);
    } catch {
      // ignore
    }
  }

  static async clear(): Promise<void> {
    const allKeys = (await AsyncStorage.getAllKeys()).filter(k => k.startsWith('cache:'));
    await AsyncStorage.multiRemove(allKeys);
  }
}
