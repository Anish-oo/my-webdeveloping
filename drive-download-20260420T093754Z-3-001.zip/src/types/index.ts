// ─────────────────────────────────────────────────────────
// TAMIL TUNES – Global TypeScript Types
// ─────────────────────────────────────────────────────────

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  year: number;
  duration: number;          // seconds
  audioUrl: string;          // streaming URL
  thumbnail: string;         // album art URL (high-res)
  thumbnailLow: string;      // album art URL (low-res for lists)
  language: string;          // always "tamil"
  mood?: MoodTag;
  isLiked?: boolean;
  isCached?: boolean;
}

export type MoodTag = 'love' | 'sad' | 'melody' | 'kuthu' | 'devotional' | 'folk';

export interface Artist {
  id: string;
  name: string;
  imageUrl: string;
  bio?: string;
  songCount?: number;
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  year: number;
  coverUrl: string;
  songs: Song[];
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  coverUrl?: string;
  gradient?: [string, string];
  songs: Song[];
  isUserCreated: boolean;
  createdAt?: number;
}

export interface PlayerState {
  currentSong: Song | null;
  queue: Song[];
  queueIndex: number;
  isPlaying: boolean;
  isBuffering: boolean;
  progress: number;          // 0–1
  duration: number;          // seconds
  position: number;          // seconds
  shuffle: boolean;
  repeatMode: 'off' | 'all' | 'one';
  volume: number;            // 0–1
}

export interface LibraryState {
  likedSongs: Song[];
  playlists: Playlist[];
  recentlyPlayed: Song[];
  downloadedSongs: Song[];
}

// ─── Music Provider Interface ─────────────────────────────
// All data sources implement this contract.
// To swap to a different API, create a new class
// that implements IMusicProvider and set it in api/index.ts.

export interface IMusicProvider {
  /**
   * Fetch a list of Tamil songs (paginated)
   * @param page  1-based page index
   * @param limit songs per page
   */
  getSongs(page?: number, limit?: number): Promise<Song[]>;

  /**
   * Full-text search: songs, artists, albums
   */
  searchSongs(query: string, limit?: number): Promise<Song[]>;

  /**
   * Fetch songs by a specific artist name
   */
  getSongsByArtist(artist: string, limit?: number): Promise<Song[]>;

  /**
   * Fetch songs released in a specific year
   */
  getSongsByYear(year: number, limit?: number): Promise<Song[]>;

  /**
   * Fetch songs in a year range (decade playlists)
   */
  getSongsByDecade(from: number, to: number, limit?: number): Promise<Song[]>;

  /**
   * Fetch a single song's details (including fresh audio URL if expired)
   */
  getSongById(id: string): Promise<Song | null>;

  /**
   * Fetch featured/trending Tamil songs for Home screen
   */
  getFeaturedSongs(limit?: number): Promise<Song[]>;

  /**
   * Fetch artists matching a query
   */
  searchArtists(query: string): Promise<Artist[]>;
}

export type RootStackParamList = {
  MainTabs: undefined;
  Player: { song?: Song };
  Playlist: { playlist: Playlist };
  Artist: { artist: Artist };
  Search: undefined;
};

export type TabParamList = {
  Home: undefined;
  Search: undefined;
  Library: undefined;
};
