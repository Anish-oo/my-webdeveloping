// ─────────────────────────────────────────────────────────
// screens/LibraryScreen.tsx
// ─────────────────────────────────────────────────────────

import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, TextInput, Modal, FlatList,
} from 'react-native';
import { StatusBar }  from 'expo-status-bar';
import { Ionicons }   from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

import { Colors, Typography, Spacing, Radius, GRADIENTS, CURATED_PLAYLISTS } from '../constants/theme';
import { useAppSelector, useAppDispatch } from '../hooks/usePlayer';
import { createPlaylist, deletePlaylist } from '../store/librarySlice';
import SongCard   from '../components/SongCard';
import PlaylistCard from '../components/PlaylistCard';

// ─── Small playlist row ───────────────────────────────────
function PlaylistRow({ name, count, gradient, onPress, onDelete }: {
  name:     string;
  count:    number;
  gradient: [string,string];
  onPress:  () => void;
  onDelete?: () => void;
}) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8} style={pl.row}>
      <LinearGradient colors={gradient} style={pl.icon} start={{x:0,y:0}} end={{x:1,y:1}}>
        <Ionicons name="musical-notes" size={22} color="rgba(255,255,255,0.85)" />
      </LinearGradient>
      <View style={pl.info}>
        <Text style={pl.name}>{name}</Text>
        <Text style={pl.meta}>{count} songs</Text>
      </View>
      {onDelete && (
        <TouchableOpacity onPress={onDelete} hitSlop={8}>
          <Ionicons name="trash-outline" size={18} color={Colors.text3} />
        </TouchableOpacity>
      )}
      <Ionicons name="chevron-forward" size={18} color={Colors.text3} />
    </TouchableOpacity>
  );
}

export default function LibraryScreen({ navigation }: any) {
  const dispatch = useAppDispatch();
  const liked    = useAppSelector(s => s.library.likedSongs);
  const playlists = useAppSelector(s => s.library.playlists);
  const recent    = useAppSelector(s => s.library.recentlyPlayed);

  const [showCreate, setShowCreate] = useState(false);
  const [plName,     setPlName]     = useState('');
  const [plDesc,     setPlDesc]     = useState('');

  const handleCreate = () => {
    if (!plName.trim()) return;
    dispatch(createPlaylist({ name: plName.trim(), description: plDesc.trim() }));
    setPlName(''); setPlDesc(''); setShowCreate(false);
  };

  const handleDelete = (id: string, name: string) => {
    Alert.alert(`Delete "${name}"?`, 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => dispatch(deletePlaylist(id)) },
    ]);
  };

  const openPlaylist = (data: any) => navigation.navigate('Playlist', { playlist: data });

  return (
    <View style={s.root}>
      <StatusBar style="light" />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 140 }}>

        {/* Header */}
        <View style={s.header}>
          <Text style={s.title}>Your Library</Text>
          <TouchableOpacity onPress={() => setShowCreate(true)} style={s.addBtn}>
            <Ionicons name="add" size={22} color={Colors.text} />
          </TouchableOpacity>
        </View>

        {/* Liked Songs */}
        <TouchableOpacity
          activeOpacity={0.82}
          style={s.likedCard}
          onPress={() => openPlaylist({
            id: 'liked', name: 'Liked Songs', description: `${liked.length} songs`,
            gradient: ['#FF416C', '#c94b4b'], songs: liked, isUserCreated: false,
          })}
        >
          <LinearGradient colors={['#FF416C','#c94b4b']} style={s.likedIcon} start={{x:0,y:0}} end={{x:1,y:1}}>
            <Ionicons name="heart" size={28} color="white" />
          </LinearGradient>
          <View style={{ flex: 1 }}>
            <Text style={s.likedTitle}>Liked Songs</Text>
            <Text style={s.likedMeta}>{liked.length} songs</Text>
          </View>
          <Ionicons name="play-circle" size={44} color={Colors.accent} />
        </TouchableOpacity>

        {/* User Playlists */}
        {playlists.length > 0 && (
          <View style={s.section}>
            <Text style={s.sTitle}>My Playlists</Text>
            {playlists.map((pl, i) => (
              <PlaylistRow
                key={pl.id}
                name={pl.name}
                count={pl.songs.length}
                gradient={GRADIENTS[i % GRADIENTS.length]}
                onPress={() => openPlaylist(pl)}
                onDelete={() => handleDelete(pl.id, pl.name)}
              />
            ))}
          </View>
        )}

        {/* Curated Playlists */}
        <View style={s.section}>
          <Text style={s.sTitle}>Curated Playlists</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: Spacing.md, paddingRight: Spacing.lg }}>
            {CURATED_PLAYLISTS.map(pl => (
              <PlaylistCard
                key={pl.id}
                name={pl.name}
                gradient={pl.gradient}
                size={132}
                onPress={() => openPlaylist({
                  id: pl.id, name: pl.name, description: pl.query,
                  gradient: pl.gradient, songs: [], isUserCreated: false, _query: pl.query,
                })}
              />
            ))}
          </ScrollView>
        </View>

        {/* Recently Played */}
        {recent.length > 0 && (
          <View style={s.section}>
            <Text style={s.sTitle}>Recently Played</Text>
            {recent.slice(0, 10).map((song, i) => (
              <SongCard key={song.id} song={song} index={i} queue={recent} compact />
            ))}
          </View>
        )}

      </ScrollView>

      {/* Create Playlist Modal */}
      <Modal visible={showCreate} animationType="slide" transparent>
        <View style={m.backdrop}>
          <View style={m.sheet}>
            <Text style={m.title}>New Playlist</Text>
            <TextInput
              placeholder="Playlist name"
              placeholderTextColor={Colors.text3}
              value={plName}
              onChangeText={setPlName}
              style={m.input}
              autoFocus
            />
            <TextInput
              placeholder="Description (optional)"
              placeholderTextColor={Colors.text3}
              value={plDesc}
              onChangeText={setPlDesc}
              style={m.input}
            />
            <View style={m.btns}>
              <TouchableOpacity onPress={() => setShowCreate(false)} style={m.cancelBtn}>
                <Text style={m.cancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleCreate} style={m.createBtn}>
                <Text style={m.createText}>Create</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  root:      { flex: 1, backgroundColor: Colors.bg },
  header:    { flexDirection:'row', justifyContent:'space-between', alignItems:'center', padding: Spacing.lg, paddingTop: 56 },
  title:     { color: Colors.text, fontSize: Typography['2xl'], fontWeight: '900' },
  addBtn:    { backgroundColor: Colors.surface2, borderRadius: Radius.full, padding: 9, borderWidth:1, borderColor:Colors.border },
  section:   { marginTop: Spacing.md, paddingHorizontal: Spacing.lg, marginBottom: Spacing.lg },
  sTitle:    { color: Colors.text, fontSize: Typography.lg, fontWeight: '800', marginBottom: Spacing.md },
  likedCard: { flexDirection:'row', alignItems:'center', marginHorizontal:Spacing.lg, backgroundColor:Colors.surface2, borderRadius:Radius.lg, padding:Spacing.md, marginBottom:Spacing.lg, borderWidth:1, borderColor:Colors.border, gap: Spacing.md },
  likedIcon: { width:56, height:56, borderRadius:Radius.md, alignItems:'center', justifyContent:'center' },
  likedTitle:{ color:Colors.text, fontSize:Typography.lg, fontWeight:'800' },
  likedMeta: { color:Colors.text2, fontSize:Typography.sm, marginTop:3 },
});

const pl = StyleSheet.create({
  row:  { flexDirection:'row', alignItems:'center', paddingVertical:10, borderBottomWidth:1, borderBottomColor:Colors.border, gap: Spacing.md },
  icon: { width:52, height:52, borderRadius:Radius.md, alignItems:'center', justifyContent:'center' },
  info: { flex:1 },
  name: { color:Colors.text, fontSize:Typography.md, fontWeight:'700' },
  meta: { color:Colors.text2, fontSize:Typography.sm, marginTop:2 },
});

const m = StyleSheet.create({
  backdrop:   { flex:1, backgroundColor:'rgba(0,0,0,0.75)', justifyContent:'flex-end' },
  sheet:      { backgroundColor:Colors.surface, borderTopLeftRadius:24, borderTopRightRadius:24, padding:Spacing.xl },
  title:      { color:Colors.text, fontSize:Typography.xl, fontWeight:'800', marginBottom:Spacing.lg },
  input:      { backgroundColor:Colors.surface2, borderRadius:Radius.md, padding:Spacing.md, color:Colors.text, fontSize:Typography.base, marginBottom:Spacing.md, borderWidth:1, borderColor:Colors.border },
  btns:       { flexDirection:'row', gap:Spacing.md, marginTop:Spacing.sm },
  cancelBtn:  { flex:1, backgroundColor:Colors.surface3, borderRadius:Radius.md, padding:14, alignItems:'center' },
  cancelText: { color:Colors.text2, fontSize:Typography.base, fontWeight:'600' },
  createBtn:  { flex:1, backgroundColor:Colors.accent, borderRadius:Radius.md, padding:14, alignItems:'center' },
  createText: { color:'white', fontSize:Typography.base, fontWeight:'700' },
});
