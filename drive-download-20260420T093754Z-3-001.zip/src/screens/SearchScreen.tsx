// ─────────────────────────────────────────────────────────
// screens/SearchScreen.tsx
// ─────────────────────────────────────────────────────────

import React, { useState, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  FlatList, ActivityIndicator, Keyboard, ListRenderItem,
} from 'react-native';
import { StatusBar }    from 'expo-status-bar';
import { Ionicons }     from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';

import { Colors, Typography, Spacing, Radius } from '../constants/theme';
import { MusicAPI }     from '../api';
import { Song }         from '../types';
import SongCard         from '../components/SongCard';

// Decade quick-filters
const DECADES = [
  { label: '80s', query: 'ilaiyaraaja 1980s tamil melody' },
  { label: '90s', query: 'ar rahman 1990s tamil hits' },
  { label: '2000s', query: 'harris jayaraj 2000s tamil' },
  { label: '2010s', query: 'anirudh 2010s tamil hits' },
  { label: '2020s', query: 'anirudh 2020s tamil new' },
];

const MOODS = [
  { label: '❤️ Love',        query: 'tamil love melody songs' },
  { label: '😢 Sad',         query: 'tamil sad songs' },
  { label: '🔥 Kuthu',       query: 'tamil kuthu dance' },
  { label: '🙏 Devotional',  query: 'tamil devotional songs' },
  { label: '🌿 Folk',        query: 'tamil folk songs' },
];

export default function SearchScreen() {
  const [query,   setQuery]   = useState('');
  const [results, setResults] = useState<Song[]>([]);
  const [loading, setLoading] = useState(false);
  const [empty,   setEmpty]   = useState(false);
  const inputRef              = useRef<TextInput>(null);
  const timerRef              = useRef<ReturnType<typeof setTimeout>>();

  useFocusEffect(useCallback(() => {
    setTimeout(() => inputRef.current?.focus(), 200);
  }, []));

  const doSearch = useCallback(async (q: string) => {
    if (!q.trim()) { setResults([]); setEmpty(false); return; }
    setLoading(true); setEmpty(false);
    try {
      const songs = await MusicAPI.searchSongs(q.trim(), 40);
      setResults(songs);
      setEmpty(songs.length === 0);
    } catch {
      setEmpty(true);
    } finally {
      setLoading(false);
    }
  }, []);

  // Debounce
  const onChangeText = (t: string) => {
    setQuery(t);
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => doSearch(t), 420);
  };

  const onChipPress = (q: string) => {
    Keyboard.dismiss();
    setQuery(q);
    doSearch(q);
  };

  const renderSong: ListRenderItem<Song> = ({ item, index }) => (
    <SongCard song={item} index={index} queue={results} showNum />
  );

  return (
    <View style={s.root}>
      <StatusBar style="light" />

      {/* Search Bar */}
      <View style={s.barWrap}>
        <View style={s.bar}>
          <Ionicons name="search" size={18} color={Colors.text2} />
          <TextInput
            ref={inputRef}
            value={query}
            onChangeText={onChangeText}
            placeholder="Songs, artists, years, moods…"
            placeholderTextColor={Colors.text3}
            style={s.input}
            returnKeyType="search"
            onSubmitEditing={() => doSearch(query)}
            autoCorrect={false}
            autoCapitalize="none"
          />
          {query.length > 0 && (
            <TouchableOpacity onPress={() => { setQuery(''); setResults([]); setEmpty(false); }}>
              <Ionicons name="close-circle" size={18} color={Colors.text2} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Results / Discovery UI */}
      {loading ? (
        <ActivityIndicator color={Colors.accent} style={{ marginTop: 48 }} size="large" />
      ) : results.length > 0 ? (
        <FlatList
          data={results}
          keyExtractor={i => i.id}
          renderItem={renderSong}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: Spacing.lg, paddingBottom: 130 }}
          ListHeaderComponent={
            <Text style={s.resultCount}>{results.length} songs found</Text>
          }
          getItemLayout={(_, idx) => ({ length: 68, offset: 68 * idx, index: idx })}
        />
      ) : empty ? (
        <View style={s.centred}>
          <Ionicons name="musical-notes-outline" size={52} color={Colors.text3} />
          <Text style={s.emptyText}>No Tamil songs found</Text>
          <Text style={s.emptyHint}>Try a different search term</Text>
        </View>
      ) : (
        /* Discovery chips */
        <View style={s.discovery}>
          <Text style={s.chipHead}>BROWSE BY DECADE</Text>
          <View style={s.chipRow}>
            {DECADES.map(d => (
              <TouchableOpacity key={d.label} onPress={() => onChipPress(d.query)} style={s.chip}>
                <Text style={s.chipText}>{d.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={[s.chipHead, { marginTop: Spacing.xl }]}>BROWSE BY MOOD</Text>
          <View style={s.chipRow}>
            {MOODS.map(m => (
              <TouchableOpacity key={m.label} onPress={() => onChipPress(m.query)} style={[s.chip, s.moodChip]}>
                <Text style={[s.chipText, s.moodChipText]}>{m.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root:    { flex: 1, backgroundColor: Colors.bg },
  barWrap: { paddingHorizontal: Spacing.lg, paddingTop: 56, paddingBottom: Spacing.md, backgroundColor: Colors.bg },
  bar:     {
    flexDirection:   'row',
    alignItems:      'center',
    backgroundColor: Colors.surface2,
    borderRadius:    Radius.lg,
    paddingHorizontal: Spacing.md,
    gap:             Spacing.sm,
    borderWidth:     1,
    borderColor:     Colors.border,
  },
  input:   { flex: 1, color: Colors.text, fontSize: Typography.base, paddingVertical: 13 },

  resultCount: { color: Colors.text2, fontSize: Typography.sm, marginVertical: Spacing.md, fontWeight: '600' },

  centred:   { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.sm },
  emptyText: { color: Colors.text2, fontSize: Typography.lg, fontWeight: '700' },
  emptyHint: { color: Colors.text3, fontSize: Typography.sm },

  discovery: { padding: Spacing.lg },
  chipHead:  { color: Colors.text3, fontSize: Typography.xs, fontWeight: '700', letterSpacing: 1.2, marginBottom: Spacing.md },
  chipRow:   { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  chip:      {
    backgroundColor: Colors.surface2,
    borderRadius:    Radius.full,
    paddingHorizontal: 18,
    paddingVertical:   10,
    borderWidth:     1,
    borderColor:     Colors.border,
  },
  chipText:     { color: Colors.text, fontSize: Typography.sm, fontWeight: '600' },
  moodChip:     { backgroundColor: Colors.accentDim, borderColor: Colors.accent + '44' },
  moodChipText: { color: Colors.accent },
});
