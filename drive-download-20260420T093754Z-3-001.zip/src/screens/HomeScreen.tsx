// ─────────────────────────────────────────────────────────
// screens/HomeScreen.tsx
// ─────────────────────────────────────────────────────────

import React, { useCallback, useEffect, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  RefreshControl, ActivityIndicator, FlatList, Image,
} from 'react-native';
import { LinearGradient }    from 'expo-linear-gradient';
import { StatusBar }         from 'expo-status-bar';
import { Ionicons }          from '@expo/vector-icons';

import { Colors, Typography, Spacing, Radius, CURATED_PLAYLISTS, TOP_ARTISTS, Shadow } from '../constants/theme';
import { MusicAPI }          from '../api';
import { CacheService }      from '../services/CacheService';
import { Song }              from '../types';
import { usePlayer }         from '../hooks/usePlayer';
import SongCard              from '../components/SongCard';
import PlaylistCard          from '../components/PlaylistCard';

// ─── Section wrapper ─────────────────────────────────────
function Section({ title, onMore, children }: { title: string; onMore?: () => void; children: React.ReactNode }) {
  return (
    <View style={s.section}>
      <View style={s.sHead}>
        <Text style={s.sTitle}>{title}</Text>
        {onMore && (
          <TouchableOpacity onPress={onMore}>
            <Text style={s.sMore}>See all</Text>
          </TouchableOpacity>
        )}
      </View>
      {children}
    </View>
  );
}

// ─── Artist Chip ─────────────────────────────────────────
function ArtistChip({ name, color, onPress }: { name: string; color: string; onPress: () => void }) {
  const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
  return (
    <TouchableOpacity onPress={onPress} style={s.artistWrap} activeOpacity={0.8}>
      <LinearGradient
        colors={[color, color + '99']}
        style={s.artistCircle}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <Text style={s.artistInitials}>{initials}</Text>
      </LinearGradient>
      <Text style={s.artistName} numberOfLines={2}>{name.split(' ')[0]}</Text>
    </TouchableOpacity>
  );
}

export default function HomeScreen({ navigation }: any) {
  const [featured,   setFeatured]   = useState<Song[]>([]);
  const [recent,     setRecent]     = useState<Song[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const { play, currentSong } = usePlayer();

  const load = useCallback(async (hard = false) => {
    const cKey = 'home_featured';
    if (!hard) {
      const cached = await CacheService.getSongs(cKey);
      if (cached?.length) { setFeatured(cached); setLoading(false); }
    }
    try {
      const songs = await MusicAPI.getFeaturedSongs(25);
      if (songs.length) {
        setFeatured(songs);
        await CacheService.setSongs(cKey, songs);
      }
    } catch (err) {
      console.warn('HomeScreen fetch failed', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(); }, []);

  const onRefresh = () => { setRefreshing(true); load(true); };

  const openPlaylist = (pl: typeof CURATED_PLAYLISTS[0]) => {
    navigation.navigate('Playlist', {
      playlist: {
        id:            pl.id,
        name:          pl.name,
        description:   pl.query,
        gradient:      pl.gradient,
        songs:         [],
        isUserCreated: false,
        _query:        pl.query,
      },
    });
  };

  const openArtist = (a: typeof TOP_ARTISTS[0]) => {
    navigation.navigate('Artist', {
      artist: { id: a.query, name: a.name, imageUrl: '', bio: '' },
    });
  };

  return (
    <View style={s.root}>
      <StatusBar style="light" />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 140 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.accent} />
        }
      >
        {/* ── Header ── */}
        <LinearGradient
          colors={[Colors.accent + '33', Colors.bg]}
          style={s.header}
        >
          <View>
            <Text style={s.greeting}>🎵 வணக்கம் (Vanakkam)</Text>
            <Text style={s.appName}>
              Tamil{' '}
              <Text style={{ color: Colors.accent }}>Tunes</Text>
            </Text>
            <Text style={s.subtitle}>1980 – April 2026 · Ad-free · Real streaming</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('Search')}
            style={s.searchBtn}
          >
            <Ionicons name="search" size={22} color={Colors.text} />
          </TouchableOpacity>
        </LinearGradient>

        {/* ── Featured Playlists ── */}
        <Section title="Featured Playlists">
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: Spacing.lg, gap: Spacing.md }}>
            {CURATED_PLAYLISTS.map(pl => (
              <PlaylistCard
                key={pl.id}
                name={pl.name}
                gradient={pl.gradient}
                size={148}
                onPress={() => openPlaylist(pl)}
              />
            ))}
          </ScrollView>
        </Section>

        {/* ── Artists ── */}
        <Section title="Artists">
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: Spacing.lg, gap: Spacing.lg }}>
            {TOP_ARTISTS.map(a => (
              <ArtistChip key={a.name} name={a.name} color={a.color} onPress={() => openArtist(a)} />
            ))}
          </ScrollView>
        </Section>

        {/* ── Featured Songs ── */}
        <Section title="Featured Songs">
          {loading ? (
            <ActivityIndicator color={Colors.accent} style={{ marginVertical: 32 }} />
          ) : featured.length === 0 ? (
            <Text style={s.empty}>No songs loaded. Check your connection.</Text>
          ) : (
            <View style={{ paddingHorizontal: Spacing.lg }}>
              {featured.slice(0, 20).map((song, i) => (
                <SongCard key={song.id} song={song} index={i} queue={featured} showNum />
              ))}
            </View>
          )}
        </Section>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:      { flex: 1, backgroundColor: Colors.bg },
  header:    { padding: Spacing.lg, paddingTop: 56, paddingBottom: Spacing.xl, flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start' },
  greeting:  { color: Colors.text2, fontSize: Typography.sm, marginBottom: 4, letterSpacing: 1 },
  appName:   { color: Colors.text, fontSize: Typography['3xl'], fontWeight: '900', lineHeight: 38 },
  subtitle:  { color: Colors.text3, fontSize: Typography.xs, marginTop: 4 },
  searchBtn: { backgroundColor: Colors.surface2, borderRadius: Radius.full, padding: 10, marginTop: 4, borderWidth:1, borderColor: Colors.border },

  section:   { marginBottom: Spacing.xl },
  sHead:     { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal: Spacing.lg, marginBottom: Spacing.md },
  sTitle:    { color: Colors.text, fontSize: Typography.lg, fontWeight: '800' },
  sMore:     { color: Colors.accent, fontSize: Typography.sm, fontWeight: '600' },

  artistWrap:     { width: 76, alignItems: 'center', gap: 6 },
  artistCircle:   { width: 66, height: 66, borderRadius: 33, alignItems:'center', justifyContent:'center', ...Shadow.card },
  artistInitials: { color: '#fff', fontSize: Typography.lg, fontWeight: '900' },
  artistName:     { color: Colors.text2, fontSize: Typography.xs, textAlign:'center', fontWeight: '600' },

  empty: { color: Colors.text2, textAlign:'center', paddingVertical: 32, paddingHorizontal: Spacing.xl },
});
