// ─────────────────────────────────────────────────────────
// screens/PlayerScreen.tsx — Full-screen music player
// ─────────────────────────────────────────────────────────

import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Image,
  Animated, Dimensions, PanResponder, StatusBar, ScrollView,
} from 'react-native';
import { LinearGradient }  from 'expo-linear-gradient';
import { BlurView }        from 'expo-blur';
import { Ionicons }        from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Colors, Typography, Spacing, Radius, Shadow } from '../constants/theme';
import { usePlayer, useAppDispatch } from '../hooks/usePlayer';

const { width: W, height: H } = Dimensions.get('window');
const ARTWORK_SIZE = W - 64;

function fmtTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2,'0')}`;
}

// ─── Seek Bar ─────────────────────────────────────────────
function SeekBar({ progress, duration, onSeek }: {
  progress: number;
  duration: number;
  onSeek:   (pos: number) => void;
}) {
  const barWidth = W - Spacing.lg * 2;
  const thumbX   = useRef(new Animated.Value(0)).current;
  const isSeeking = useRef(false);
  const seekPos   = useRef(0);

  useEffect(() => {
    if (!isSeeking.current) {
      thumbX.setValue(progress * barWidth);
    }
  }, [progress, barWidth]);

  const responder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder:  () => true,
    onPanResponderGrant: () => { isSeeking.current = true; },
    onPanResponderMove: (_, gs) => {
      const x = Math.max(0, Math.min(barWidth, gs.moveX - Spacing.lg));
      thumbX.setValue(x);
      seekPos.current = (x / barWidth) * duration;
    },
    onPanResponderRelease: () => {
      isSeeking.current = false;
      onSeek(seekPos.current);
    },
  });

  return (
    <View style={sk.wrap} {...responder.panHandlers}>
      <View style={sk.track}>
        <Animated.View
          style={[sk.fill, {
            width: thumbX.interpolate({
              inputRange: [0, barWidth],
              outputRange: ['0%', '100%'],
              extrapolate: 'clamp',
            }),
          }]}
        />
        <Animated.View style={[sk.thumb, { transform: [{ translateX: thumbX }] }]} />
      </View>
      <View style={sk.times}>
        <Text style={sk.time}>{fmtTime(progress * duration)}</Text>
        <Text style={sk.time}>{fmtTime(duration)}</Text>
      </View>
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────
export default function PlayerScreen({ navigation }: any) {
  const insets = useSafeAreaInsets();
  const {
    currentSong,
    isPlaying,
    isBuffering,
    progress,
    duration,
    position,
    shuffle,
    repeatMode,
    togglePlay,
    next,
    prev,
    seek,
    cycleRepeat,
    toggleShuff,
    like,
    isLiked,
  } = usePlayer();

  // Pulse animation for artwork
  const pulse = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    if (isPlaying) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, { toValue: 1.03, duration: 1800, useNativeDriver: true }),
          Animated.timing(pulse, { toValue: 1.00, duration: 1800, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulse.setValue(1);
    }
  }, [isPlaying]);

  if (!currentSong) {
    return (
      <View style={[s.root, { justifyContent:'center', alignItems:'center' }]}>
        <Ionicons name="musical-notes" size={64} color={Colors.text3} />
        <Text style={{ color: Colors.text2, marginTop: 16 }}>No song selected</Text>
      </View>
    );
  }

  const liked = isLiked(currentSong.id);
  const repeatIcon =
    repeatMode === 'one'  ? 'repeat-outline' :
    repeatMode === 'all'  ? 'repeat'         : 'repeat';
  const repeatColor =
    repeatMode !== 'off' ? Colors.accent : Colors.text3;

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" />

      {/* Blurred background from artwork */}
      <Image
        source={{ uri: currentSong.thumbnail }}
        style={StyleSheet.absoluteFill}
        blurRadius={40}
      />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(6,6,16,0.82)' }]} />

      <ScrollView
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
        bounces={false}
      >
        {/* Header */}
        <View style={[s.header, { paddingTop: insets.top + 12 }]}>
          <TouchableOpacity onPress={() => navigation.goBack()} hitSlop={8} style={s.iconBtn}>
            <Ionicons name="chevron-down" size={30} color={Colors.text} />
          </TouchableOpacity>
          <View style={{ alignItems: 'center' }}>
            <Text style={s.headerLabel}>NOW PLAYING</Text>
            <Text style={s.headerSub}>{currentSong.year}</Text>
          </View>
          <TouchableOpacity hitSlop={8} style={s.iconBtn}>
            <Ionicons name="ellipsis-horizontal" size={24} color={Colors.text} />
          </TouchableOpacity>
        </View>

        {/* Artwork */}
        <View style={s.artWrap}>
          <Animated.View style={{ transform: [{ scale: pulse }] }}>
            <Image
              source={{ uri: currentSong.thumbnail }}
              style={s.artwork}
              defaultSource={require('../assets/placeholder.png')}
            />
          </Animated.View>
        </View>

        {/* Song Info + Like */}
        <View style={s.infoRow}>
          <View style={{ flex: 1 }}>
            <Text style={s.songTitle} numberOfLines={2}>{currentSong.title}</Text>
            <Text style={s.songArtist}>{currentSong.artist}</Text>
            <Text style={s.songAlbum}>{currentSong.album}</Text>
          </View>
          <TouchableOpacity onPress={() => like(currentSong)} hitSlop={8} style={s.likeBtn}>
            <Ionicons
              name={liked ? 'heart' : 'heart-outline'}
              size={30}
              color={liked ? Colors.accent : Colors.text2}
            />
          </TouchableOpacity>
        </View>

        {/* Seek Bar */}
        <View style={{ paddingHorizontal: Spacing.lg }}>
          <SeekBar progress={progress} duration={duration} onSeek={seek} />
        </View>

        {/* Controls */}
        <View style={s.controls}>
          {/* Shuffle */}
          <TouchableOpacity onPress={toggleShuff} hitSlop={8} style={s.ctrlBtn}>
            <Ionicons
              name="shuffle"
              size={24}
              color={shuffle ? Colors.accent : Colors.text3}
            />
          </TouchableOpacity>

          {/* Previous */}
          <TouchableOpacity onPress={prev} hitSlop={8} style={s.ctrlBtn}>
            <Ionicons name="play-skip-back" size={36} color={Colors.text} />
          </TouchableOpacity>

          {/* Play / Pause */}
          <TouchableOpacity onPress={togglePlay} activeOpacity={0.85} style={s.playBtn}>
            <LinearGradient
              colors={[Colors.accent, '#FF8C00']}
              style={s.playGrad}
              start={{x:0,y:0}} end={{x:1,y:1}}
            >
              {isBuffering ? (
                <Ionicons name="hourglass" size={32} color="white" />
              ) : (
                <Ionicons
                  name={isPlaying ? 'pause' : 'play'}
                  size={34}
                  color="white"
                  style={isPlaying ? {} : { marginLeft: 4 }}
                />
              )}
            </LinearGradient>
          </TouchableOpacity>

          {/* Next */}
          <TouchableOpacity onPress={next} hitSlop={8} style={s.ctrlBtn}>
            <Ionicons name="play-skip-forward" size={36} color={Colors.text} />
          </TouchableOpacity>

          {/* Repeat */}
          <TouchableOpacity onPress={cycleRepeat} hitSlop={8} style={s.ctrlBtn}>
            <Ionicons name={repeatIcon} size={24} color={repeatColor} />
            {repeatMode === 'one' && (
              <View style={s.repeatOneBadge}>
                <Text style={s.repeatOneText}>1</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Badges */}
        <View style={s.badges}>
          <View style={s.badge}>
            <Text style={s.badgeLabel}>MOOD</Text>
            <Text style={s.badgeValue}>{currentSong.mood ?? '—'}</Text>
          </View>
          <View style={s.badge}>
            <Text style={s.badgeLabel}>ALBUM</Text>
            <Text style={s.badgeValue} numberOfLines={1}>{currentSong.album || '—'}</Text>
          </View>
          <View style={s.badge}>
            <Text style={s.badgeLabel}>YEAR</Text>
            <Text style={s.badgeValue}>{currentSong.year}</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:      { flex:1, backgroundColor: Colors.bg },
  header:    { flexDirection:'row', justifyContent:'space-between', alignItems:'center', paddingHorizontal: Spacing.lg, paddingBottom: Spacing.lg },
  headerLabel: { color: Colors.text2, fontSize: Typography.xs, fontWeight: '700', letterSpacing: 2, textTransform:'uppercase' },
  headerSub: { color: Colors.text3, fontSize: Typography.xs },
  iconBtn:   { padding: 8 },
  artWrap:   { alignItems:'center', marginVertical: Spacing.xl },
  artwork:   {
    width:        ARTWORK_SIZE,
    height:       ARTWORK_SIZE,
    borderRadius: Radius.xl,
    backgroundColor: Colors.surface3,
    ...Shadow.player,
  },
  infoRow:   { flexDirection:'row', alignItems:'flex-start', paddingHorizontal: Spacing.lg, marginBottom: Spacing.xl, gap: Spacing.lg },
  songTitle: { color: Colors.text, fontSize: Typography.xl, fontWeight: '900', lineHeight: 30 },
  songArtist:{ color: Colors.text2, fontSize: Typography.base, marginTop: 4, fontWeight: '500' },
  songAlbum: { color: Colors.text3, fontSize: Typography.sm, marginTop: 2 },
  likeBtn:   { padding: 8, marginTop: 4 },
  controls:  { flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingHorizontal: Spacing.lg, marginBottom: Spacing.xl, marginTop: Spacing.sm },
  ctrlBtn:   { padding: 10, position:'relative' },
  playBtn:   { ...Shadow.player },
  playGrad:  { width: 72, height: 72, borderRadius: 36, alignItems:'center', justifyContent:'center' },
  repeatOneBadge: { position:'absolute', top:6, right:6, backgroundColor: Colors.accent, borderRadius: 6, width:12, height:12, alignItems:'center', justifyContent:'center' },
  repeatOneText:  { color:'white', fontSize:7, fontWeight:'900' },
  badges:    { flexDirection:'row', paddingHorizontal: Spacing.lg, gap: Spacing.md },
  badge:     { flex:1, backgroundColor: Colors.surface2, borderRadius: Radius.md, padding: Spacing.md, borderWidth:1, borderColor: Colors.border },
  badgeLabel:{ color: Colors.text3, fontSize: 9, fontWeight:'700', letterSpacing:1, marginBottom:4 },
  badgeValue:{ color: Colors.text, fontSize: Typography.sm, fontWeight:'700', textTransform:'capitalize' },
});

const sk = StyleSheet.create({
  wrap:  { paddingBottom: Spacing.sm },
  track: { height: 4, backgroundColor: Colors.surface3, borderRadius: 2, position:'relative', marginBottom: Spacing.sm },
  fill:  { height:'100%', backgroundColor: Colors.accent, borderRadius: 2, position:'absolute' },
  thumb: { position:'absolute', top:-6, width:16, height:16, borderRadius:8, backgroundColor:Colors.accent, marginLeft:-8, shadowColor: Colors.accent, shadowOpacity: 0.6, shadowRadius:6, shadowOffset:{width:0,height:0} },
  times: { flexDirection:'row', justifyContent:'space-between' },
  time:  { color: Colors.text3, fontSize: Typography.xs },
});
