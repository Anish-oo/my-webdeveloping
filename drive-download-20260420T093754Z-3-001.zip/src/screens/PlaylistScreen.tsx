// ─────────────────────────────────────────────────────────
// screens/PlaylistScreen.tsx
// ─────────────────────────────────────────────────────────

import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Image, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons }       from '@expo/vector-icons';

import { Colors, Typography, Spacing, Radius, GRADIENTS, Shadow } from '../constants/theme';
import { MusicAPI }    from '../api';
import { CacheService } from '../services/CacheService';
import { Song }        from '../types';
import { usePlayer }   from '../hooks/usePlayer';
import SongCard        from '../components/SongCard';

export function PlaylistScreen({ route, navigation }: any) {
  const { playlist } = route.params as { playlist: any };
  const [songs,   setSongs]   = useState<Song[]>(playlist.songs ?? []);
  const [loading, setLoading] = useState(false);
  const { play }              = usePlayer();

  const gradient: [string,string] = playlist.gradient ?? GRADIENTS[0];

  useEffect(() => {
    if (songs.length === 0 && playlist._query) {
      loadSongs(playlist._query);
    }
  }, []);

  const loadSongs = async (query: string) => {
    setLoading(true);
    const cKey = `pl_${playlist.id}`;
    const cached = await CacheService.getSongs(cKey);
    if (cached?.length) { setSongs(cached); setLoading(false); return; }
    try {
      const s = await MusicAPI.searchSongs(query, 40);
      setSongs(s);
      await CacheService.setSongs(cKey, s);
    } catch {}
    setLoading(false);
  };

  return (
    <View style={p.root}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 130 }}>
        {/* Hero */}
        <LinearGradient colors={[gradient[0]+'88', Colors.bg]} style={p.hero}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={p.back}>
            <Ionicons name="chevron-back" size={26} color={Colors.text} />
          </TouchableOpacity>
          <LinearGradient colors={gradient} style={p.cover} start={{x:0,y:0}} end={{x:1,y:1}}>
            <Ionicons name="musical-notes" size={64} color="rgba(255,255,255,0.7)" />
          </LinearGradient>
          <Text style={p.name}>{playlist.name}</Text>
          <Text style={p.desc}>{playlist.description}</Text>
          {songs.length > 0 && (
            <TouchableOpacity onPress={() => play(songs[0], songs)} style={p.playBtn}>
              <LinearGradient colors={[Colors.accent,'#FF8C00']} style={p.playGrad} start={{x:0,y:0}} end={{x:1,y:1}}>
                <Ionicons name="play" size={24} color="white" style={{ marginLeft:4 }} />
                <Text style={p.playText}>Play All</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </LinearGradient>

        {/* Songs */}
        <View style={{ paddingHorizontal: Spacing.lg }}>
          {loading ? (
            <ActivityIndicator color={Colors.accent} style={{ marginVertical: 40 }} size="large" />
          ) : songs.length === 0 ? (
            <Text style={p.empty}>No songs in this playlist yet.</Text>
          ) : songs.map((song, i) => (
            <SongCard key={song.id} song={song} index={i} queue={songs} showNum />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

// ─────────────────────────────────────────────────────────
// screens/ArtistScreen.tsx
// ─────────────────────────────────────────────────────────
export function ArtistScreen({ route, navigation }: any) {
  const { artist }            = route.params;
  const [songs,   setSongs]   = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);
  const { play }              = usePlayer();

  useEffect(() => {
    (async () => {
      const cKey = `artist_${artist.id}`;
      const cached = await CacheService.getSongs(cKey);
      if (cached?.length) { setSongs(cached); setLoading(false); return; }
      try {
        const s = await MusicAPI.getSongsByArtist(artist.name, 40);
        setSongs(s);
        await CacheService.setSongs(cKey, s);
      } catch {}
      setLoading(false);
    })();
  }, []);

  const initials = artist.name.split(' ').map((w:string) => w[0]).join('').slice(0,2).toUpperCase();

  return (
    <View style={a.root}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 130 }}>
        {/* Hero */}
        <View style={a.hero}>
          {artist.imageUrl ? (
            <Image source={{ uri: artist.imageUrl }} style={StyleSheet.absoluteFill} resizeMode="cover" />
          ) : null}
          <View style={[StyleSheet.absoluteFill, { backgroundColor:'rgba(7,7,15,0.65)' }]} />
          <TouchableOpacity onPress={() => navigation.goBack()} style={a.back}>
            <Ionicons name="chevron-back" size={26} color={Colors.text} />
          </TouchableOpacity>
          <View style={a.avatar}>
            <Text style={a.initials}>{initials}</Text>
          </View>
          <Text style={a.name}>{artist.name}</Text>
          {artist.bio ? <Text style={a.bio}>{artist.bio}</Text> : null}
          {songs.length > 0 && (
            <TouchableOpacity onPress={() => play(songs[0], songs)} style={a.playBtn}>
              <LinearGradient colors={[Colors.accent,'#FF8C00']} style={p.playGrad} start={{x:0,y:0}} end={{x:1,y:1}}>
                <Ionicons name="play" size={22} color="white" style={{ marginLeft:4 }} />
                <Text style={p.playText}>Play All</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>

        {/* Songs */}
        <View style={{ paddingHorizontal: Spacing.lg, paddingTop: Spacing.md }}>
          {loading ? (
            <ActivityIndicator color={Colors.accent} style={{ marginVertical: 40 }} size="large" />
          ) : songs.length === 0 ? (
            <Text style={p.empty}>No songs found.</Text>
          ) : songs.map((song, i) => (
            <SongCard key={song.id} song={song} index={i} queue={songs} showNum />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

// ─── Shared styles ────────────────────────────────────────
const p = StyleSheet.create({
  root:     { flex:1, backgroundColor: Colors.bg },
  hero:     { alignItems:'center', paddingTop:60, paddingBottom: Spacing.xl, paddingHorizontal: Spacing.lg },
  back:     { position:'absolute', top:56, left:Spacing.lg, backgroundColor:'rgba(0,0,0,0.4)', borderRadius:Radius.full, padding:8, zIndex:10 },
  cover:    { width:168, height:168, borderRadius:Radius.xl, alignItems:'center', justifyContent:'center', marginBottom:Spacing.lg, ...Shadow.player },
  name:     { color:Colors.text, fontSize:Typography['2xl'], fontWeight:'900', textAlign:'center', marginBottom:6 },
  desc:     { color:Colors.text2, fontSize:Typography.sm, textAlign:'center', marginBottom: Spacing.lg },
  playBtn:  { marginTop: Spacing.sm },
  playGrad: { flexDirection:'row', alignItems:'center', paddingHorizontal:32, paddingVertical:13, borderRadius:Radius.full, gap:8, ...Shadow.card },
  playText: { color:'white', fontSize:Typography.base, fontWeight:'700' },
  empty:    { color:Colors.text2, textAlign:'center', paddingVertical:40 },
});

const a = StyleSheet.create({
  root:     { flex:1, backgroundColor: Colors.bg },
  hero:     { minHeight:280, justifyContent:'flex-end', padding: Spacing.lg, paddingBottom: Spacing.xl },
  back:     { position:'absolute', top:52, left:Spacing.lg, backgroundColor:'rgba(0,0,0,0.5)', borderRadius:Radius.full, padding:8, zIndex:10 },
  avatar:   { width:90, height:90, borderRadius:45, backgroundColor: Colors.accent, alignItems:'center', justifyContent:'center', marginBottom: Spacing.md, ...Shadow.player },
  initials: { color:'white', fontSize:Typography['2xl'], fontWeight:'900' },
  name:     { color:Colors.text, fontSize:Typography['3xl'], fontWeight:'900', marginBottom:6 },
  bio:      { color:Colors.text2, fontSize:Typography.sm, marginBottom: Spacing.lg },
  playBtn:  { marginTop: Spacing.md },
});
