// ─────────────────────────────────────────────────────────
// components/SongCard.tsx — Song row for lists
// ─────────────────────────────────────────────────────────

import React, { memo } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Image, ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Song }    from '../types';
import { Colors, Typography, Spacing, Radius } from '../constants/theme';
import { usePlayer } from '../hooks/usePlayer';

interface Props {
  song:     Song;
  index?:   number;
  queue?:   Song[];
  showNum?: boolean;
  compact?: boolean;
  onLongPress?: (song: Song) => void;
}

function fmtDur(s: number) {
  return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
}

const SongCard = memo(({ song, index, queue, showNum, compact, onLongPress }: Props) => {
  const { currentSong, isPlaying, isBuffering, play, like, isLiked } = usePlayer();
  const active  = currentSong?.id === song.id;
  const liked   = isLiked(song.id);

  return (
    <TouchableOpacity
      onPress={() => play(song, queue)}
      onLongPress={() => onLongPress?.(song)}
      activeOpacity={0.72}
      style={[styles.container, active && styles.active, compact && styles.compact]}
    >
      {/* Index / playing indicator */}
      {showNum && (
        <View style={styles.indexBox}>
          {active ? (
            isBuffering
              ? <ActivityIndicator size="small" color={Colors.accent} />
              : <Ionicons name={isPlaying ? 'musical-notes' : 'pause'} size={16} color={Colors.accent} />
          ) : (
            <Text style={styles.index}>{(index ?? 0) + 1}</Text>
          )}
        </View>
      )}

      {/* Thumbnail */}
      <Image
        source={{
          uri: song.thumbnailLow || song.thumbnail,
          headers: { 'User-Agent': 'TamilTunes/1.0' },
        }}
        style={[styles.thumb, compact && styles.thumbSmall]}
        defaultSource={require('../assets/placeholder.png')}
      />

      {/* Info */}
      <View style={styles.info}>
        <Text
          style={[styles.title, active && styles.titleActive]}
          numberOfLines={1}
        >
          {song.title}
        </Text>
        <Text style={styles.sub} numberOfLines={1}>
          {song.artist}{song.year ? ` · ${song.year}` : ''}
        </Text>
      </View>

      {/* Duration + Like */}
      <View style={styles.right}>
        {!compact && (
          <Text style={styles.dur}>{fmtDur(song.duration)}</Text>
        )}
        <TouchableOpacity onPress={() => like(song)} hitSlop={8}>
          <Ionicons
            name={liked ? 'heart' : 'heart-outline'}
            size={20}
            color={liked ? Colors.accent : Colors.text3}
          />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
});

const styles = StyleSheet.create({
  container: {
    flexDirection:  'row',
    alignItems:     'center',
    paddingVertical: 9,
    paddingHorizontal: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  active: {
    backgroundColor: Colors.accentDim,
    borderRadius:    Radius.sm,
    borderBottomColor: 'transparent',
  },
  compact: {
    paddingVertical: 6,
  },
  indexBox: {
    width: 28,
    alignItems: 'center',
  },
  index: {
    color:    Colors.text3,
    fontSize: Typography.sm,
  },
  thumb: {
    width:        50,
    height:       50,
    borderRadius: Radius.sm,
    marginRight:  Spacing.md,
    backgroundColor: Colors.surface3,
  },
  thumbSmall: {
    width:  40,
    height: 40,
  },
  info: {
    flex: 1,
    marginRight: Spacing.sm,
  },
  title: {
    color:      Colors.text,
    fontSize:   Typography.md,
    fontWeight: '600',
  },
  titleActive: {
    color: Colors.accent,
  },
  sub: {
    color:     Colors.text2,
    fontSize:  Typography.sm,
    marginTop: 3,
  },
  right: {
    flexDirection: 'row',
    alignItems:    'center',
    gap:           10,
  },
  dur: {
    color:    Colors.text3,
    fontSize: Typography.xs,
  },
});

SongCard.displayName = 'SongCard';
export default SongCard;
