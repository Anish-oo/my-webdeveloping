// ─────────────────────────────────────────────────────────
// components/PlaylistCard.tsx — Gradient playlist card
// ─────────────────────────────────────────────────────────

import React, { memo } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons }       from '@expo/vector-icons';

import { Colors, Typography, Radius, Shadow, Spacing } from '../constants/theme';

interface Props {
  name:        string;
  description?: string;
  songCount?:  number;
  gradient:    [string, string];
  coverUrl?:   string;
  size?:       number;
  onPress:     () => void;
}

const PlaylistCard = memo(({
  name, description, songCount, gradient, coverUrl, size = 148, onPress,
}: Props) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.82}
      style={[styles.wrap, { width: size }]}
    >
      <LinearGradient
        colors={gradient}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.cover, { width: size, height: size }]}
      >
        {coverUrl ? (
          <Image source={{ uri: coverUrl }} style={StyleSheet.absoluteFill} resizeMode="cover" />
        ) : (
          <Ionicons name="musical-notes" size={size * 0.3} color="rgba(255,255,255,0.6)" />
        )}

        {/* Bottom label overlay */}
        <View style={styles.overlay}>
          <Text style={[styles.name, { fontSize: size < 120 ? 11 : 13 }]} numberOfLines={2}>
            {name}
          </Text>
        </View>
      </LinearGradient>

      {songCount !== undefined && (
        <Text style={styles.meta}>{songCount} songs</Text>
      )}
      {description && (
        <Text style={styles.desc} numberOfLines={1}>{description}</Text>
      )}
    </TouchableOpacity>
  );
});

const styles = StyleSheet.create({
  wrap: {
    marginRight: Spacing.md,
  },
  cover: {
    borderRadius:    Radius.lg,
    alignItems:      'center',
    justifyContent:  'flex-end',
    overflow:        'hidden',
    marginBottom:    6,
    ...Shadow.card,
  },
  overlay: {
    width:           '100%',
    paddingHorizontal: 10,
    paddingVertical:   10,
    background:       'transparent',
  },
  name: {
    color:       '#FFFFFF',
    fontWeight:  '800',
    lineHeight:  17,
    textShadowColor: 'rgba(0,0,0,0.6)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  meta: {
    color:    Colors.text2,
    fontSize: Typography.xs,
  },
  desc: {
    color:    Colors.text3,
    fontSize: Typography.xs,
    marginTop: 1,
  },
});

PlaylistCard.displayName = 'PlaylistCard';
export default PlaylistCard;
