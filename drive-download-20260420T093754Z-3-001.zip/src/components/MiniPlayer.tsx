// ─────────────────────────────────────────────────────────
// components/MiniPlayer.tsx
// Sticky bottom bar shown over the tab navigator.
// Tapping it opens the full PlayerScreen.
// ─────────────────────────────────────────────────────────

import React, { memo } from 'react';
import {
  View, Text, TouchableOpacity, Image, StyleSheet,
  ActivityIndicator, Animated,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons }      from '@expo/vector-icons';
import { BlurView }      from 'expo-blur';

import { usePlayer }     from '../hooks/usePlayer';
import { Colors, Typography, Spacing, Shadow } from '../constants/theme';

const MiniPlayer = memo(() => {
  const nav  = useNavigation<any>();
  const {
    currentSong, isPlaying, isBuffering,
    progress, togglePlay, next,
  } = usePlayer();

  if (!currentSong) return null;

  return (
    <TouchableOpacity
      activeOpacity={0.92}
      onPress={() => nav.navigate('Player')}
      style={styles.wrap}
    >
      {/* Blurred background */}
      <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill} />

      {/* Progress bar */}
      <View style={styles.progressBg}>
        <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
      </View>

      <View style={styles.row}>
        {/* Album art */}
        <Image
          source={{ uri: currentSong.thumbnailLow || currentSong.thumbnail }}
          style={styles.art}
          defaultSource={require('../assets/placeholder.png')}
        />

        {/* Title & artist */}
        <View style={styles.info}>
          <Text style={styles.title} numberOfLines={1}>{currentSong.title}</Text>
          <Text style={styles.artist} numberOfLines={1}>{currentSong.artist}</Text>
        </View>

        {/* Controls */}
        <View style={styles.controls}>
          {/* Play / Pause */}
          <TouchableOpacity onPress={togglePlay} hitSlop={8} style={styles.btn}>
            {isBuffering
              ? <ActivityIndicator size="small" color={Colors.text} />
              : <Ionicons
                  name={isPlaying ? 'pause' : 'play'}
                  size={26}
                  color={Colors.text}
                />
            }
          </TouchableOpacity>

          {/* Next */}
          <TouchableOpacity onPress={next} hitSlop={8} style={styles.btn}>
            <Ionicons name="play-skip-forward" size={24} color={Colors.text} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
});

const styles = StyleSheet.create({
  wrap: {
    position:        'absolute',
    bottom:          0,
    left:            0,
    right:           0,
    overflow:        'hidden',
    borderTopWidth:  1,
    borderTopColor:  Colors.border,
    backgroundColor: 'rgba(10,10,22,0.85)',
    ...Shadow.card,
  },
  progressBg: {
    height:          3,
    backgroundColor: Colors.surface3,
  },
  progressFill: {
    height:          3,
    backgroundColor: Colors.accent,
  },
  row: {
    flexDirection: 'row',
    alignItems:    'center',
    paddingHorizontal: Spacing.lg,
    paddingVertical:   Spacing.sm,
    gap: Spacing.md,
  },
  art: {
    width:        46,
    height:       46,
    borderRadius: 8,
    backgroundColor: Colors.surface3,
  },
  info: {
    flex: 1,
  },
  title: {
    color:      Colors.text,
    fontSize:   Typography.md,
    fontWeight: '700',
  },
  artist: {
    color:     Colors.text2,
    fontSize:  Typography.sm,
    marginTop: 2,
  },
  controls: {
    flexDirection: 'row',
    alignItems:    'center',
    gap:           4,
  },
  btn: {
    padding: 6,
  },
});

MiniPlayer.displayName = 'MiniPlayer';
export default MiniPlayer;
