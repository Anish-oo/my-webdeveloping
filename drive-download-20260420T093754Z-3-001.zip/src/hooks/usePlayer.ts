// ─────────────────────────────────────────────────────────
// hooks/usePlayer.ts — Typed Redux + TrackPlayer hooks
// ─────────────────────────────────────────────────────────

import { useDispatch, useSelector, TypedUseSelectorHook } from 'react-redux';
import {
  useTrackPlayerEvents,
  useProgress,
  Event,
  State as TPState,
  usePlaybackState,
} from 'react-native-track-player';
import { useCallback, useEffect } from 'react';

import { RootState, AppDispatch } from '../store';
import {
  playSong,
  togglePlayPause,
  skipToNext,
  skipToPrevious,
  seekTo,
  setRepeat,
  toggleShuffle,
  setCurrentSong,
  setProgress,
  setPlaybackState,
} from '../store/playerSlice';
import { toggleLike, addToRecentlyPlayed } from '../store/librarySlice';
import { Song } from '../types';

// ─── Typed Redux hooks ────────────────────────────────────
export const useAppDispatch = () => useDispatch<AppDispatch>();
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;

// ─── Main player hook ─────────────────────────────────────
export function usePlayer() {
  const dispatch = useAppDispatch();
  const player   = useAppSelector(s => s.player);
  const library  = useAppSelector(s => s.library);
  const progress = useProgress(250); // poll every 250 ms
  const pbState  = usePlaybackState();

  // Sync TrackPlayer progress → Redux
  useEffect(() => {
    dispatch(setProgress({
      position: progress.position,
      duration: progress.duration,
    }));
  }, [progress.position, progress.duration]);

  // Sync playback state → Redux
  useEffect(() => {
    dispatch(setPlaybackState({
      state:    pbState.state ?? TPState.None,
      position: progress.position,
      duration: progress.duration,
    }));
  }, [pbState.state]);

  // Listen for track-change to update currentSong in Redux
  useTrackPlayerEvents([Event.PlaybackActiveTrackChanged], async event => {
    if (event.track) {
      const song = player.queue.find(s => s.id === event.track!.id);
      if (song) {
        dispatch(setCurrentSong(song));
        dispatch(addToRecentlyPlayed(song));
      }
    }
  });

  const play = useCallback((song: Song, queue?: Song[]) => {
    dispatch(playSong({ song, queue: queue ?? [song] }));
    dispatch(addToRecentlyPlayed(song));
  }, [dispatch]);

  const isLiked = useCallback((id: string) =>
    library.likedSongs.some(s => s.id === id),
  [library.likedSongs]);

  const like = useCallback((song: Song) => {
    dispatch(toggleLike(song));
  }, [dispatch]);

  return {
    // State
    currentSong:  player.currentSong,
    isPlaying:    player.isPlaying,
    isBuffering:  player.isBuffering,
    progress:     player.progress,
    position:     player.position,
    duration:     player.duration,
    shuffle:      player.shuffle,
    repeatMode:   player.repeatMode,
    queue:        player.queue,

    // Actions
    play,
    togglePlay:   () => dispatch(togglePlayPause()),
    next:         () => dispatch(skipToNext()),
    prev:         () => dispatch(skipToPrevious()),
    seek:         (pos: number) => dispatch(seekTo(pos)),
    cycleRepeat:  () => {
      const next = player.repeatMode === 'off' ? 'all'
                 : player.repeatMode === 'all' ? 'one' : 'off';
      dispatch(setRepeat(next));
    },
    toggleShuff:  () => dispatch(toggleShuffle()),

    // Library
    like,
    isLiked,
  };
}
