// ─────────────────────────────────────────────────────────
// navigation/TabNavigator.tsx — Bottom tab + stack nav
// ─────────────────────────────────────────────────────────

import React from 'react';
import { View, StyleSheet } from 'react-native';
import { createBottomTabNavigator }  from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { BlurView }                  from 'expo-blur';
import { Ionicons }                  from '@expo/vector-icons';

import HomeScreen                     from '../screens/HomeScreen';
import SearchScreen                   from '../screens/SearchScreen';
import LibraryScreen                  from '../screens/LibraryScreen';
import PlayerScreen                   from '../screens/PlayerScreen';
import { PlaylistScreen, ArtistScreen } from '../screens/PlaylistScreen';
import MiniPlayer                     from '../components/MiniPlayer';

import { Colors, Typography } from '../constants/theme';

const Tab   = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

// ─── Tab Bar ──────────────────────────────────────────────
function TabBar({ state, descriptors, navigation }: any) {
  const tabItems = [
    { name:'Home',    icon:'home',          iconO:'home-outline'          },
    { name:'Search',  icon:'search',        iconO:'search-outline'        },
    { name:'Library', icon:'library',       iconO:'library-outline'       },
  ];

  return (
    <View style={t.tabWrap}>
      {/* Mini player sits above the tab bar */}
      <MiniPlayer />
      <BlurView intensity={80} tint="dark" style={t.blur}>
        <View style={t.bar}>
          {state.routes.map((route: any, i: number) => {
            const focused = state.index === i;
            const item    = tabItems[i];
            return (
              <View key={route.key} style={t.tab}>
                <Ionicons
                  name={(focused ? item.icon : item.iconO) as any}
                  size={24}
                  color={focused ? Colors.accent : Colors.text3}
                  onPress={() => navigation.navigate(route.name)}
                />
                {focused && <View style={t.dot} />}
              </View>
            );
          })}
        </View>
      </BlurView>
    </View>
  );
}

// ─── Bottom Tabs ──────────────────────────────────────────
function BottomTabs() {
  return (
    <Tab.Navigator
      tabBar={props => <TabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tab.Screen name="Home"    component={HomeScreen}    />
      <Tab.Screen name="Search"  component={SearchScreen}  />
      <Tab.Screen name="Library" component={LibraryScreen} />
    </Tab.Navigator>
  );
}

// ─── Root Stack ───────────────────────────────────────────
export default function RootNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MainTabs" component={BottomTabs} />
      <Stack.Screen
        name="Player"
        component={PlayerScreen}
        options={{ presentation: 'modal', animation: 'slide_from_bottom' }}
      />
      <Stack.Screen name="Playlist" component={PlaylistScreen} />
      <Stack.Screen name="Artist"   component={ArtistScreen} />
    </Stack.Navigator>
  );
}

const t = StyleSheet.create({
  tabWrap: { position:'absolute', bottom:0, left:0, right:0 },
  blur:    { borderTopWidth:1, borderTopColor: Colors.border },
  bar:     { flexDirection:'row', paddingVertical:10, paddingBottom:28 },
  tab:     { flex:1, alignItems:'center', justifyContent:'center', paddingTop:4, gap:4 },
  dot:     { width:4, height:4, borderRadius:2, backgroundColor: Colors.accent },
});
