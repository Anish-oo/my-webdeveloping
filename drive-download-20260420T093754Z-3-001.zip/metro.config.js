const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Support additional audio formats
config.resolver.assetExts.push(
  // Audio
  'mp3', 'mp4', 'aac', 'flac', 'ogg', 'wav', 'm4a',
  // Fonts
  'ttf', 'otf', 'woff', 'woff2',
  // Images
  'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg',
);

// Enable symlinks for monorepos
config.resolver.unstable_enableSymlinks = true;

// Increase transform cache size for better performance
config.transformer.getTransformOptions = async () => ({
  transform: {
    experimentalImportSupport: false,
    inlineRequires: true, // speeds up startup
  },
});

module.exports = config;
