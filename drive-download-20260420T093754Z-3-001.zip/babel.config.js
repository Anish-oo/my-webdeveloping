module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      // Required for react-native-reanimated
      'react-native-reanimated/plugin',
      // Required for redux-persist
      [
        'module-resolver',
        {
          root: ['./src'],
          extensions: ['.ios.js', '.android.js', '.js', '.ts', '.tsx', '.json'],
          alias: {
            '@api':        './src/api',
            '@components': './src/components',
            '@constants':  './src/constants',
            '@hooks':      './src/hooks',
            '@navigation': './src/navigation',
            '@screens':    './src/screens',
            '@services':   './src/services',
            '@store':      './src/store',
            '@types':      './src/types',
          },
        },
      ],
    ],
  };
};
