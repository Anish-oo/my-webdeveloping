# 🎵 Tamil Tunes — Complete Setup Guide

## What You're Getting
A **production-ready React Native (Expo)** music streaming app that:
- ✅ Streams real Tamil songs via JioSaavn API (no hardcoded data)
- ✅ Background playback (screen off, app minimised)
- ✅ Lock screen & notification controls
- ✅ Search by song, artist, mood, decade
- ✅ Liked songs, custom playlists, recently played
- ✅ Zero ads — completely clean
- ✅ Offline caching (6-hour cache)
- ✅ Covers 1980–April 2026

---

## 📋 Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| Node.js | 18+ | https://nodejs.org |
| npm / yarn | latest | comes with Node |
| Expo CLI | latest | `npm i -g expo-cli` |
| EAS CLI | latest | `npm i -g eas-cli` |
| Android Studio | latest | https://developer.android.com/studio |
| Java JDK | 17+ | https://adoptium.net |

---

## 🚀 Step 1 — Install Dependencies

```bash
cd TamilTunes
npm install
```

---

## 🔤 Step 2 — Download Real Fonts (Required)

The app uses **Outfit** font family. Download the TTF files from Google Fonts:

1. Go to: https://fonts.google.com/specimen/Outfit
2. Click **"Download family"**
3. Extract the ZIP
4. Copy these files into `src/assets/fonts/`:
   - `Outfit-Regular.ttf`
   - `Outfit-Medium.ttf`
   - `Outfit-SemiBold.ttf`
   - `Outfit-Bold.ttf`
   - `Outfit-Black.ttf`

> **Note:** The app works without fonts (falls back to system font). Step 2 is optional.

---

## 📱 Step 3A — Run on Android (USB Cable)

```bash
# Enable USB Debugging on your Android phone:
# Settings → Developer Options → USB Debugging → ON

# Connect phone via USB, then:
npx expo start --android
```

Your phone will install **Expo Go** automatically and open the app.

---

## 📱 Step 3B — Run on Android Emulator

```bash
# Open Android Studio → Virtual Device Manager → Start an emulator
npx expo start --android
```

---

## 📦 Step 4 — Build Standalone APK (Install Directly)

This creates a real `.apk` file you can share and install without Expo Go.

```bash
# One-time: login to Expo account (free)
eas login

# One-time: configure EAS project
eas build:configure

# Build APK (takes ~10-15 min on cloud)
eas build --platform android --profile apk

# Download the APK link shown in terminal
# Transfer to phone → install → done!
```

> **First Build Tip:** EAS builds on Expo's cloud servers (free tier = 30 builds/month).

---

## 🔄 How to Swap the Music Source

### Option A — Use a Different Free API

1. Create `src/api/MyNewProvider.ts`
2. Implement `IMusicProvider` (8 methods from `src/types/index.ts`)
3. In `src/api/index.ts`, change:

```typescript
// BEFORE
import { JioSaavnProvider } from './JioSaavnProvider';
export const MusicAPI = new JioSaavnProvider();

// AFTER
import { MyNewProvider } from './MyNewProvider';
export const MusicAPI = new MyNewProvider();
```

### Option B — Use Your Own Backend

```typescript
// src/api/MyBackendProvider.ts
import { IMusicProvider, Song, Artist } from '../types';

const API_BASE = 'https://your-api.com/v1';

export class MyBackendProvider implements IMusicProvider {
  async getSongs(page = 1, limit = 30): Promise<Song[]> {
    const res = await fetch(`${API_BASE}/songs?page=${page}&limit=${limit}`);
    const data = await res.json();
    return data.songs; // map to Song interface
  }
  // ... implement remaining 7 methods
}
```

---

## 📁 Project Structure

```
TamilTunes/
├── App.tsx                          # Entry: registers audio service
├── app.json                         # Expo & Android config
├── eas.json                         # Build profiles
├── package.json                     # Dependencies
│
└── src/
    ├── api/
    │   ├── index.ts                 # ← Swap provider HERE
    │   └── JioSaavnProvider.ts      # Real JioSaavn API
    │
    ├── store/
    │   ├── index.ts                 # Redux root store
    │   ├── playerSlice.ts           # Audio player state
    │   └── librarySlice.ts          # Library / likes / playlists
    │
    ├── screens/
    │   ├── HomeScreen.tsx           # Playlists, artists, featured
    │   ├── SearchScreen.tsx         # Live search + mood chips
    │   ├── LibraryScreen.tsx        # Liked, playlists, recents
    │   ├── PlayerScreen.tsx         # Full-screen player
    │   └── PlaylistScreen.tsx       # Playlist + Artist screens
    │
    ├── components/
    │   ├── SongCard.tsx             # Reusable song row
    │   ├── MiniPlayer.tsx           # Bottom sticky player
    │   └── PlaylistCard.tsx         # Gradient playlist card
    │
    ├── services/
    │   ├── AudioService.ts          # Background audio setup
    │   └── CacheService.ts          # AsyncStorage caching
    │
    ├── hooks/
    │   └── usePlayer.ts             # Player + Redux hooks
    │
    ├── navigation/
    │   └── TabNavigator.tsx         # Stack + bottom tabs
    │
    ├── constants/
    │   └── theme.ts                 # Colors, fonts, spacing
    │
    ├── types/
    │   └── index.ts                 # TypeScript types + IMusicProvider
    │
    └── assets/
        ├── fonts/                   # Outfit TTF files
        ├── icon.png                 # App icon (1024×1024)
        ├── splash.png               # Splash screen
        └── placeholder.png          # Album art fallback
```

---

## 🎨 Customisation

### Change Accent Color
In `src/constants/theme.ts`:
```typescript
accent: '#FF4500',  // Change to any color
```

### Add More Tamil Artists to Home Screen
In `src/constants/theme.ts`, add to `TOP_ARTISTS`:
```typescript
{ name: 'Sid Sriram', query: 'sid sriram tamil', color: '#30cfd0' },
```

### Add More Curated Playlists
In `src/constants/theme.ts`, add to `CURATED_PLAYLISTS`:
```typescript
{ id:'pl_ghazal', name:'Tamil Ghazals', query:'tamil ghazal songs', gradient:GRADIENTS[5] },
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| `No songs loading` | Check internet connection. API: saavn.dev must be accessible |
| `Font error on startup` | Delete font stubs, or comment out Font.loadAsync in App.tsx |
| `TrackPlayer not initialised` | Restart Metro: `npx expo start -c` |
| `Background audio stops` | Ensure `UIBackgroundModes: audio` in app.json iOS section |
| `Build fails: JAVA_HOME` | Set JAVA_HOME to JDK 17 path |
| `Emulator too slow` | Enable Hardware Acceleration in AVD settings |

---

## 🔒 Android Permissions (Already Configured)

`app.json` already declares:
- `INTERNET` — streaming audio
- `FOREGROUND_SERVICE` — keep audio alive
- `FOREGROUND_SERVICE_MEDIA_PLAYBACK` — Android 14+ media service
- `WAKE_LOCK` — prevent CPU sleep during playback
- `RECEIVE_BOOT_COMPLETED` — resume after reboot

---

## 📡 API Reference (saavn.dev)

The free, open-source JioSaavn REST API used:

```
GET https://saavn.dev/api/search/songs?query=ar+rahman+tamil&limit=30
GET https://saavn.dev/api/songs/{id}
GET https://saavn.dev/api/search/artists?query=ilaiyaraaja
```

- No API key required
- Returns real 160kbps MP3 streaming URLs
- Tamil, Hindi, Telugu, Kannada songs available
- App filters to Tamil only (language === 'tamil')

---

## 🚀 Publishing to Play Store

```bash
# 1. Create keystore
eas credentials

# 2. Build AAB (Android App Bundle)
eas build --platform android --profile production

# 3. Submit to Play Store
eas submit --platform android
```

---

*Tamil Tunes — Built with ❤️ for Tamil music lovers*
*1980 – April 2026 · Ad-free · Real streaming*
